Binaries for Linux platform, see "demo.sh" for examples.

First, you should install RIC to your "home" directories (by run "install_RIC.sh")

