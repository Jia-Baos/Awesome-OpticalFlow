RIC "../data/KITTI/000008_10.png"  "../data/KITTI/000008_11.png" "../data/KITTI/000008_10_match.txt"
RIC "../data/MPI-Sintel/frame_0001.png"  "../data/MPI-Sintel/frame_0002.png" "../data/MPI-Sintel/frame_0001_match.txt"
