Binaries for windows platform, see "demo.bat" for examples.

Note that, the matching results are obtained from CPM method, other methods are also fine for RIC.

