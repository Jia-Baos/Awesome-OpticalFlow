

#if __cplusplus
  extern "C" {
  #endif

    __declspec(dllexport) void ComputeFlow(float* myOFParams, float* flowX, float* flowY, float* im1Data, float* im2Data, float* xMatches, float* yMatches, float* sMatches);

  #if __cplusplus
  }
  #endif



