
#include <Windows.h>
#include "ComputeMatches.h"
#include "ComputeFlow.h"

#define NEWA(type,n) (type*)malloc(sizeof(type)*long(n))

// DLL export fct
//extern "C" __declspec(dllexport) int ComputeFlowDLL(int argc, char** argv);
//extern "C" __declspec(dllexport) int ComputeMatchesDLL(int argc, char** argv);

// Main computation fct
//float* ComputeFlow(color_image_t *inIm1, color_image_t *inIm2, float *myOFParams);
//void ComputeMatches(color_image_t *cIm1, color_image_t *cIm2, dm_params_t dmParams);
