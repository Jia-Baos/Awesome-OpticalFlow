#include "LDOFMOCO.h"
#include <iostream>
#include <sys\timeb.h>

int main(int argc, char ** argv)
{
	// Init:
	int width = 192;
	int height = 256;
	int stride = ((width + 3) / 4) * 4;
	float *im1Data = NULL, *im2Data = NULL;
	float *myDMparams, *myOFparams;

	// Arrange custom parameters:
	myDMparams    = NEWA(float, 3 * sizeof(float));
	myDMparams[0] = (float) width;
	myDMparams[1] = (float) height;
	myDMparams[2] = 1.0;

	myOFparams = NEWA(float, 10 * sizeof(float));
	myOFparams[0] = (float)width;
	myOFparams[1] = (float)height;
	myOFparams[2] = 4.0;
	myOFparams[3] = 7.0;
	myOFparams[4] = 7.0;
	myOFparams[5] = 0.04;
	myOFparams[6] = 0.45;
	myOFparams[7] = 0.45;
	myOFparams[8] = 0.95;
	myOFparams[9] = 25;
		
	// Arrange pixel data:	
	im1Data = NEWA(float, stride*height*sizeof(float));
	im2Data = NEWA(float, stride*height*sizeof(float));

	// Deep Matching:
	float* xMatches = NEWA(float, stride*height*sizeof(float));
	float* yMatches = NEWA(float, stride*height*sizeof(float));
	float* sMatches = NEWA(float, stride*height*sizeof(float));

	memset(xMatches, 0, stride*height*sizeof(float));
	memset(yMatches, 0, stride*height*sizeof(float));
	memset(sMatches, 0, stride*height*sizeof(float));

	ComputeMatches(myDMparams, im1Data, im2Data, xMatches, yMatches, sMatches);
	
	// Deep Flow:
	float* flowX = NEWA(float, stride*height*sizeof(float));
	float* flowY = NEWA(float, stride*height*sizeof(float));

	memset(flowX, 0, stride*height*sizeof(float));
	memset(flowY, 0, stride*height*sizeof(float));

	ComputeFlow(myOFparams, flowX, flowY, im1Data, im2Data, xMatches, yMatches, sMatches);

	//Cleanup:
	free(im1Data);
	free(im2Data);
	free(myDMparams);
	free(myOFparams);
	free(xMatches);
	free(yMatches);
	free(sMatches);
	free(flowX);
	free(flowY);

	return 0;
}

