#include "ComputeMatches.h"
#include "image.h"
#include "io.h"

int ComputeMatches(float* myDMparams, float* im1Data, float* im2Data, float* xMatches, float* yMatches, float* sMatches)
{
	// Inits:
	image_t *inIm1 = NULL, *inIm2 = NULL;
	float_image* deepMatches = NULL;
	const corres_t* matches;
	int nMatches, x0, y0, x1, y1, i, stride, width, height;
	float score;

	// Arrange image pixels:
	width	= (int)myDMparams[0];
	height	= (int)myDMparams[1];
	stride	= ((width + 3) / 4) * 4;

	inIm1	= image_new(width, height);
	inIm2	= image_new(width, height);

	memcpy(inIm1->data, im1Data, stride*height*sizeof(float));
	memcpy(inIm2->data, im2Data, stride*height*sizeof(float));
	
	//Setup DeepMatching params:
	dm_params_t dmParams;
	set_default_dm_params(&dmParams);
	dmParams.prior_img_downscale = (int)myDMparams[2];

	// Compute matches:
	deepMatches = deep_matching(inIm1, inIm2, &dmParams, NULL);

	// Arrange matches
	nMatches = (int)deepMatches->ty;
	matches  = (corres_t*)deepMatches->pixels;

	for (i = 0; i < nMatches; i++)
	{
		const corres_t* matchRow = matches + i;

		x0 = (int)matchRow->x0;
		y0 = (int)matchRow->y0;
		x1 = (int)matchRow->x1;
		y1 = (int)matchRow->y1;

		score = matchRow->score;

		xMatches[y0*stride + x0] = (float)(x1 - x0);
		yMatches[y0*stride + x0] = (float)(y1 - y0);
		sMatches[y0*stride + x0] = score;
	}

	// Cleanup
	free_image(deepMatches);
	image_delete(inIm1);
	image_delete(inIm2);

	return 1;
}


int ComputeMatchesEXE(float* myDMparams, float* im1Data, float* im2Data, float* xMatches, float* yMatches, float* sMatches)
{
	// Inits:
	image_t *inIm1 = NULL, *inIm2 = NULL;
	float_image* deepMatches = NULL;
	const corres_t* matches;
	int nMatches, x0, y0, x1, y1, i, stride, width, height;
	float score;

	// Arrange image pixels:
	width  = myDMparams[0];
	height = myDMparams[1];
	stride = ((width + 3) / 4) * 4;

	// Load color images:
	color_image_t *cIm1 = NULL, *cIm2 = NULL;

	cIm1 = color_image_load("c:/1.ppm");
	cIm2 = color_image_load("c:/2.ppm");

	// Convert input images to grayscale:
	inIm1 = image_gray_from_color(cIm1);
	inIm2 = image_gray_from_color(cIm2);

	//Setup DeepMatching params:
	dm_params_t dmParams;
	set_default_dm_params(&dmParams);
	dmParams.prior_img_downscale = (int)myDMparams[2];
	
	// Compute matches:
	deepMatches = deep_matching(inIm1, inIm2, &dmParams, NULL);
	
	// Arrange matches
	
	nMatches = (int) deepMatches->ty;
	matches  = (corres_t*)deepMatches->pixels;

	for (i = 0; i < nMatches; i++)
	{
		const corres_t* matchRow = matches + i;

		x0 = (int)matchRow->x0;
		y0 = (int)matchRow->y0;
		x1 = (int)matchRow->x1;
		y1 = (int)matchRow->y1;

		score = matchRow->score;

		xMatches[y0*stride + x0] = (float)(x1 - x0);
		yMatches[y0*stride + x0] = (float)(y1 - y0);
		sMatches[y0*stride + x0] = score;
	}

	fprintf(stderr, "NB matches found: %d\n", nMatches);

	// Cleanup
	free_image(deepMatches);
	image_delete(inIm1);
	image_delete(inIm2);
	
	return 1;
}

