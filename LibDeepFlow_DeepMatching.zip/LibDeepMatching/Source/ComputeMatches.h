
extern "C" __declspec(dllexport) int ComputeMatchesEXE(float* myDMparams, float* im1Data, float* im2Data, float* xMatches, float* yMatches, float* sMatches);
extern "C" __declspec(dllexport) int ComputeMatches(float* myDMparams, float* im1Data, float* im2Data, float* xMatches, float* yMatches, float* sMatches);
