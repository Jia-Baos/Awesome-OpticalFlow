Binaries for windows platform, see "demo.bat" for examples.

