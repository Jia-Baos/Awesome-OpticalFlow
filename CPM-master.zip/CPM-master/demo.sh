./CPM "./data/Middlebury/frame10.png"  "./data/Middlebury/frame11.png" "./out/Middlebury_match.txt"
./CPM "./data/KITTI/000008_10.png"  "./data/KITTI/000008_11.png" "./out/KITTI_match.txt"
./CPM "./data/MPI-Sintel/frame_0001.png"  "./data/MPI-Sintel/frame_0002.png" "./out/MPI-Sintel_match.txt"
